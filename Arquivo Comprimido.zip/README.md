# first_view
Automated reader of the Brazilian Official Diary
